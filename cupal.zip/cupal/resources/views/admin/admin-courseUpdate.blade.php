<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add course</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-addCourse.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    


    <div class="addContainer">
        <div class="wrapper">
            <a href="{{ route('admin-addCourse') }}" style="float: right;" class=""><i class="fa-solid fa-x"></i></a>
            <div class="add">
                <p class="p6">Update Course</p>
                @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
                <form action="{{ route('admin-updateCourse') }}" method="post">
                    @csrf
                    <input type="hidden" placeholder="" name="id" value="{{ $course->id }}">
                    <label for="">Acronym</label>
                    <input type="text" placeholder="" name="acronym" value="{{ $course->acronym }}">
                    <span style="color: red">@error('acronym'){{ $message }}@enderror</span><br>
                    <label for="">Course name</label>
                    <input type="text" placeholder="" name="cname" value="{{ $course->course }}">
                    <span style="color: red">@error('cname'){{ $message }}@enderror</span><br>
                    <button type="submit" class="mt-3 btn btn-success btn-sm">Update</button>
                </form>
            </div>
        </div>
    </div>

</body>
</html>