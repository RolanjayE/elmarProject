<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User list</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-addCourse.css') }}">
</head>
<body>

<div class="bg">

    </div>

    <div class="addContainer">
        <div class="wrapper">
            <a href="{{ route('admin-home') }}" class="btn btn-primary mb-4">Back</a>
            <div class="add">
                <input type="search" placeholder="Search" class="mb-2">
               <table>
                    <tr>
                        <th>Username</th>
                        <th>Operation</th>
                    </tr>
                    @foreach ($users as $user)
                        <tr>
                            <td>{{ $user->username }}</td>
                            <td style="display: flex; gap:10px">
                                <a href="{{ route('admin-deleteUser', ['id' => $user->id ]) }}" style="font-size: 11px" class="btn btn-danger">Delete </a>
                                <a href="{{ route('admin-userUpdate', ['id' => $user->id ]) }}" style="font-size: 11px" class="btn btn-primary">Update</a>
                            </td>
                            
                        </tr>
                    @endforeach
               </table>
            </div>
        </div>
    </div>
    
</body>
</html>