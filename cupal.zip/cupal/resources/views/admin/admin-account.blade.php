<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Users</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-addCourse.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-account.css') }}">
    
    <link rel="stylesheet" href="{{ asset('admin/admin-home.css') }}">
</head>
<body>

    <div class="mainADmin">
        <div class="sideLeft">
            
            <ul>
                <li><a href="{{ route('admin-home') }}"><i class="fa-solid fa-gauge"></i> Main dashboard</a></li>
                <li><a href="{{ route('admin-addCourse') }}"><i class="fa-solid fa-folder"></i>  Add Course</a></li>
                <li><a href="{{ route('admin-addUsers') }}"><i class="fa-solid fa-user"></i> Add Users</a></li>
                <li><a href="{{ route('admin-eventAdmin') }}"><i class="fa-solid fa-calendar-days"></i> Add Event</a></li>
                <li><a href="{{ route('admin-course') }}"><i class="fa-regular fa-address-card"></i> Profiles</a></li>
                <li><a href="{{ route('admin-jobs') }}"><i class="fa-solid fa-chart-simple"></i> Jobs</a></li>
                <li><a href="{{ route('admin-report') }}"><i class="fa-solid fa-chart-simple"></i> Report</a></li>
                <li><a style="background-color: white; color: black;" href="{{ route('admin-account') }}"><i class="fa-solid fa-gears"></i> Settings</a></li>
                <li><a href="{{ route('logout') }}"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
            </ul>
        </div>
        <div class="sideRight">
            <div class="adminHeader">
                <i class="menu1 fa-solid fa-bars mt-4"></i>
            </div>

            <div class="allDataHere">
                <p class="p3 mb-4">Settings</p>
                <div class="account">
                    @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
                    <p class="p1">My Account</p>
                    <form action="{{ route('admin-myAccount') }}" method="post">
                        @csrf
                        <label for="">Username</label>
                        <input type="text" placeholder="" name="username" value="{{ $users->username }}">
                        <span style="color: red">@error('username'){{ $message }}@enderror</span><br>
                        <label for="">Password</label>
                        <input type="text" placeholder="" name="pass">
                        <span style="color: red">@error('pass'){{ $message }}@enderror</span><br>
                        <button type="submit" class="mt-3 btn btn-success btn-sm">Save</button>
                    </form>
                </div>
                
            </div>


        </div>
    </div>


</body>
</html>