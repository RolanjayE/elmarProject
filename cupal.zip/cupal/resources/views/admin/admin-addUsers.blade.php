<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Users</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-addCourse.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-home.css') }}">


    
  
</head>
<body>

    <div class="mainADmin mb-4">
        <div class="sideLeft">
            
            <ul>
                <li><a href="{{ route('admin-home') }}"><i class="fa-solid fa-gauge"></i> Main dashboard</a></li>
                <li><a href="{{ route('admin-addCourse') }}"><i class="fa-solid fa-folder"></i>  Add Course</a></li>
                <li><a style="background-color: white; color: black;" href="{{ route('admin-addUsers') }}"><i class="fa-solid fa-user"></i> Add Users</a></li>
                <li><a href="{{ route('admin-eventAdmin') }}"><i class="fa-solid fa-calendar-days"></i> Add Event</a></li>
                <li><a href="{{ route('admin-course') }}"><i class="fa-regular fa-address-card"></i> Profiles</a></li>
                <li><a href="{{ route('admin-jobs') }}"><i class="fa-solid fa-chart-simple"></i> Jobs</a></li>
                <li><a href="{{ route('admin-report') }}"><i class="fa-solid fa-chart-simple"></i> Report</a></li>
                <li><a href="{{ route('admin-account') }}"><i class="fa-solid fa-gears"></i> Settings</a></li>
                <li><a href="{{ route('logout') }}"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
            </ul>
        </div>
        <div class="sideRight">
            <!-- <div class="adminHeader">
                <i class="menu1 fa-solid fa-bars mt-4"></i>
            </div> -->

            <div class="allDataHere">
                <form action="{{ route('admin-importData') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <input type="file" name="csv_file">
                    
                    <p style="color: red" >@error('csv_file'){{ $message }}@enderror</p>
                    <button class="btn btn-success btn-sm mb-2" type="submit">Upload CSV</button>
                </form>
                <p class="p3 mb-4">Users</p>
                @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
                <form action="{{ route('admin-addUser') }}" method="post">
                    @csrf
                    <label for="">Schoold ID</label>
                    <input type="text" placeholder="" name="username">
                    <span style="color: red">@error('username'){{ $message }}@enderror</span><br>
                    <label for="">Password</label>
                    <input type="text" placeholder="" name="pass">
                    <span style="color: red">@error('pass'){{ $message }}@enderror</span><br>
                    <button type="submit" class="mt-3 btn btn-success btn-sm">Save</button>
                </form>
                
                <div class="table mt-4">
                    <table id="example" class="table table-striped mt-2" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Username</th>
                                    <th>Operation</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($users as $user)
                                    <tr>
                                        <td>{{ $user->username }}</td>
                                        <td>
                                            <a href="{{ route('admin-deleteUser', ['id' => $user->id ]) }}" style="font-size: 11px" class="btn btn-danger btn-sm">Delete </a>
                                            <a href="{{ route('admin-userUpdate', ['id' => $user->id ]) }}" style="font-size: 11px" class="btn btn-primary btn-sm">Update</a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        <tfoot>
                            <tr>
                                <th>Username</th>
                                <th>Operation</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>

            </div>

            

        </div>
    </div>
<!-- 
    
    <div class="bg">

    </div>

    <div class="addContainer">
        <div class="wrapper">
            <a href="{{ route('admin-home') }}" class="btn btn-success mb-4">Home</a>
            <a href="{{ route('admin-userList') }}" class="btn btn-primary mb-4">User list</a>
            <div class="add">
                <p class="p6">Add Users</p>
                @if(session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif
                <form action="{{ route('admin-addUser') }}" method="post">
                    @csrf
                    <label for="">Schoold ID</label>
                    <input type="text" placeholder="" name="username">
                    <span style="color: red">
                                @error('username')
                                    {{ $message }}
                                @enderror
                        </span><br>
                    <label for="">Password</label>
                    <input type="text" placeholder="" name="pass">
                    <span style="color: red">
                                @error('pass')
                                    {{ $message }}
                                @enderror
                        </span><br>
                    <button style="width:100%;" type="submit" class="mt-3 btn btn-success">Save</button>
                </form>
            </div>
        </div>
    </div> -->
    
    <script>
        new DataTable('#example');
    </script>


</body>
</html>