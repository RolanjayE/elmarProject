<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-person.css') }}">

</head>
<body>
    

    <div class="course-container">
        <div class="wrapper1">
            <a style="float: right;" href="{{ route('admin-course') }}">back</a>
            <div class="person">
               <!-- <h1>{{ $profileID }}</h1> -->
               <div class="leftt">
                    @if($profiles->profile !== "n/a")
                        <img style="border-radius: 100%; width: 200px; height: 200px;" src="{{ asset('storage/photos/' . $profiles->profile) }}" alt="Profile Photo">
                    @else
                        <img style="border-radius: 100%; width: 200px; height: 200px;" class="img2" src="{{ asset('image/banner.jpg') }}" alt=""> 
                    @endif
                </div>
               <div class="rightt">
                    <!-- person profile -->
                   <div class="information">
                        <p>Personal Information</p>
                        <div class="user-table">
                            <div class="header">Firstname:</div>
                            <div class="data">{{ $profiles->firstname }}</div>
                        </div>
                        <div class="user-table">
                            <div class="header">Lastname:</div>
                            <div class="data">{{ $profiles->lastname }}</div>
                        </div>
                        <div class="user-table">
                            <div class="header">Middlename:</div>
                            <div class="data">{{ $profiles->middlename }}</div>
                        </div>
                        <div class="user-table">
                            <div class="header">Gender:</div>
                            <div class="data">{{ $profiles->gender }}</div>
                        </div>
                        <div class="user-table">
                            <div class="header">Status:</div>
                            <div class="data">{{ $profiles->stats }}</div>
                        </div>
                        <div class="user-table">
                            <div class="header">Birth:</div>
                            <div class="data">{{ $profiles->birth }}</div>
                        </div>
                   </div>
                @if($contact !== null)
                   <div class="information">
                        <p class="mt-3">Contact information</p>
                        <div class="user-table">
                            <div class="header">Gmail</div>
                            <div class="data">{{ $contact->gmail }}</div>
                        </div>
                        <div class="user-table">
                            <div class="header">Street:</div>
                            <div class="data">{{ $contact->street }}</div>
                        </div>
                        <div class="user-table">
                            <div class="header">City:</div>
                            <div class="data">{{ $contact->city }}</div>
                        </div>
                        <div class="user-table">
                            <div class="header">State:</div>
                            <div class="data">{{ $contact->state }}</div>
                        </div>
                   </div>
                @endif

                @if($education !== null)
                   <div class="information">
                        <p class="mt-3">Education</p>
                        <div class="user-table">
                            <div class="header">Elementary Education</div>
                            <div class="data">{{ $education->elem }}</div>
                        </div>
                        <div class="user-table">
                            <div class="header">Elementary year graduted</div>
                            <div class="data">{{ $education->yearElem }}</div>
                        </div>
                        <div class="user-table">
                            <div class="header">High school education</div>
                            <div class="data">{{ $education->highSchool }}</div>
                        </div>
                        <div class="user-table">
                            <div class="header">High school year gradute</div>
                            <div class="data">{{ $education->yearhighSchool }}</div>
                        </div>
                        <div class="user-table">
                            <div class="header">Senior High School</div>
                            <div class="data">{{ $education->senior }}</div>
                        </div>
                        <div class="user-table">
                            <div class="header">Senior High School year gradute</div>
                            <div class="data">{{ $education->YearSenior }}</div>
                        </div>
                   </div>
                @endif

                   @if($ask !== null)
                    <div class="information">
                            <p class="mt-3">Question</p>
                            <div class="user-table">
                                <div class="header">Do you have jobs ? </div>
                                <div class="data">{{ $ask->job }}</div>
                            </div>
                            <div class="user-table">
                                <div class="header">Job related to the course ?</div>
                                <div class="data">{{ $ask->related }}</div>
                            </div>
                    </div>
                   @endif

                   @if($jobs !== null)
                    <div class="informations">
                            <p class="mt-3">My Jobs history</p>
                            @foreach ($jobs as $job)
                                <div class="user-table">
                                    <div class="header">Company name </div>
                                    <div class="data">{{ $job->company }}</div>
                                </div>
                                <div class="user-table">
                                    <div class="header">Job title ?</div>
                                    <div class="data">{{ $job->title }}</div>
                                </div>
                                <div class="user-table heloow">
                                    <div class="header">Position </div>
                                    <div class="data">{{ $job->position }}</div>
                                </div>
                            @endforeach
                    </div>
                   @endif


               </div>
            </div>
        </div>
    </div>

</body>
</html>