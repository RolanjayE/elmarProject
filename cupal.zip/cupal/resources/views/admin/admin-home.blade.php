<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-home.css') }}">
</head>
<body>
   

    <div class="mainADmin">
        <div class="sideLeft">
            
            <ul>
                <li><a style="background-color: white; color: black;" href="{{ route('admin-home') }}"><i class="fa-solid fa-gauge"></i> Main dashboard</a></li>
                <li><a href="{{ route('admin-addCourse') }}"><i class="fa-solid fa-folder"></i>  Add Course</a></li>
                <li><a href="{{ route('admin-addUsers') }}"><i class="fa-solid fa-user"></i> Add Users</a></li>
                <li><a href="{{ route('admin-eventAdmin') }}"><i class="fa-solid fa-calendar-days"></i> Add Event</a></li>
                <li><a href="{{ route('admin-course') }}"><i class="fa-regular fa-address-card"></i> Profiles</a></li>
                <li><a href="{{ route('admin-jobs') }}"><i class="fa-solid fa-chart-simple"></i> Jobs</a></li>
                <li><a href="{{ route('admin-report') }}"><i class="fa-solid fa-chart-simple"></i> Report</a></li>
                <li><a href="{{ route('admin-account') }}"><i class="fa-solid fa-gears"></i> Settings</a></li>
                <li><a href="{{ route('logout') }}"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
            </ul>
        </div>
        <div class="sideRight">
            <div class="adminHeader">
                <i class="menu1 fa-solid fa-bars mt-4"></i>
            </div>

            <div class="allDataHere">
                <p class="p3 mb-4">Dashboard</p>
                <div class="board-con">
                    @foreach ($courseCounts as $course => $count)
                        <div class="adminBoard">
                            <p class="p6">{{ $course }}</p>
                            <p style"" class="p1 heah">{{ $count }}</p>
                        </div>
                    @endforeach
                </div>
                <p class="p3 mt-3">Event</p>
                <div class="board-con">
                    <div class="adminBoard">
                        <p class="p6">Total post</p>
                        <p style"" class="p1 heah">{{ $event }}</p>
                    </div>
                </div>
            </div>


        </div>
    </div>





</body>
</html>