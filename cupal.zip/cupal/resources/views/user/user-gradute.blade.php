<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Basic</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-basic.css') }}">
</head>
<body>

    <div class="bg">
                
    </div>

    <div class="container-all">
        <div class="wrapper">
            <div class="form-con">
                <a href="{{ route('user-home') }}" class="btn btn-primary">back</a>
                <p class="p6">Basic information</p>
                <div class="con">
                    <form action="">
                        <label for="">Program name</label>
                        <input type="text" placeholder="">

                        <div class="flex">
                            <div class="f-box">
                                <label for="">Degree Level</label>
                                <input type="text" placeholder="">
                            </div>
                            <div class="f-box">
                                <label for="">Date of Graduation</label>
                                <input type="text" placeholder="">
                            </div>
                        </div>


                        <button style="width:100%;" type="submit" class="mt-4 btn btn-success">Save information</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
</body>
</html>