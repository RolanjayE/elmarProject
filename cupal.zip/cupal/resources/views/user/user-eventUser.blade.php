<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('user/user-event.css') }}">
    <title>Event</title>
</head>
<body>



    <div class="headerMain">
        <div class="headEvent">
            <div class="eventleft">
                <div class="lebox">
                    <input type="search" placeholder="Search" id="searchInput" oninput="searchEvents()">
                </div>
                <div>
                    <div class="lebox"><a href="{{ route('user-home') }}">Home</a></div>
                </div>
            </div>
        </div>
        <div class="header-wrapper">
            @foreach ($events as $event)
                <div class="header-box mb-2 event-item">
                    <div class="content-info">
                        <p class="p11">Date started: <span>{{ \Carbon\Carbon::parse($event->started)->format('F j, Y') }}</span></p>
                        <p class="p11">Date Ended: <span>{{ \Carbon\Carbon::parse($event->end)->format('F j, Y') }}</span></p>
                        <p class="decrip">{{ $event->desc }}</p>
                    </div>
                    <div class="content-img">
                        <img class="img2" src="{{ asset('storage/photos/' . $event->photo) }}" alt="Profile Photo">
                    </div>
                </div>
            @endforeach
        </div>
    </div>

    <script>
    function searchEvents() {
        var input, filter, events, eventItem, i, txtValue;
        input = document.getElementById("searchInput");
        filter = input.value.toUpperCase();
        events = document.getElementsByClassName("event-item");

        for (i = 0; i < events.length; i++) {
            eventItem = events[i];
            txtValue = eventItem.innerText || eventItem.textContent;
            
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                eventItem.style.display = "";
            } else {
                eventItem.style.display = "none";
            }
        }
    }
</script>
    
</body>
</html>