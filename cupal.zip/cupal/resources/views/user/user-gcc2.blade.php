<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GCC2</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-basic.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-batch.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-gcc.css') }}">
</head>
<body>

    <div class="bg">
                
    </div>

    <div class="container-all">
        <div class="wrapper">
            <div class="form-con">
                
                <a href="{{ route('user-home') }}"><i class="fa-regular fa-circle-xmark hehahe"></i></a>
                @if(session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif
                <p class="p6">I studied at Gingoog City Colleges and graduated with ?</p>
                <p class="haha">Select Here:</p>
                <span style="color: red">
                            @error('year')
                                {{ $message }}
                            @enderror
                    </span><br>
                <div class="con">
                    @foreach($courses as $course)
                       <div class="course-con" onclick="selectDiv(this)">
                            <p style="display: none" class="p1">{{ $course->id }}</p>
                            <p class="p1">{{ $course->acronym }}</p>
                            <!-- <p class="p4"> {{ $course->course}}</p> -->
                       </div>
                    @endforeach
                </div>
                <div class="con2">
                    <form action="{{ route('user-updateAddProfileBasic') }}" method="post">
                        @csrf
                        <label for="">Year graduated</label>
                        <!-- <input placeholder="year graduated 2023" name="year">  -->
                        <select name="year" id="">
                            <option value="2023">-- Select --</option>
                            <option value="2023">2023</option>
                            <option value="2022">2022</option>
                            <option value="2021">2021</option>
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>
                            <option value="2016">2016</option>
                            <option value="2015">2015</option>
                        </select>
                        <input type="hidden" id="selected-value" placeholder="Selected Value" name="courseID">
                        <span style="color: red">
                            @error('courseID')
                                {{ $message }}
                            @enderror
                    </span><br>
                        <button style="width:100%;" type="submit" class="mt-4 btn btn-success btn-sm">Save information</button>  
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
    function selectDiv(selectedDiv) {
        var courseContainers = document.querySelectorAll(".course-con");

        courseContainers.forEach(function(container) {
            container.style.backgroundColor = ""; // Reset background color for all divs
        });

        selectedDiv.style.backgroundColor = "green"; // Change background color of the selected div

        var selectedText = selectedDiv.querySelector(".p1").textContent;
        document.getElementById("selected-value").value = selectedText;
    }
</script>

    
</body>
</html>