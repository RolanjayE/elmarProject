<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update employment</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-batch.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-basic.css') }}">
</head>
<body>

    <div class="bg">
                
    </div>

    <div class="container-all">
        <div class="wrapper">
            <div class="form-con">
                <a href="{{ route('user-home') }}"><i class="fa-regular fa-circle-xmark hehahe"></i></a>
                <p class="p6">Update employment information</p>
                <div class="con">
                    <form action="{{ route('user-addUpdateemployment') }}" method="post">
                        @csrf
                        <input type="hidden" value="{{ $answer }}" name="id">
                        <label for="">Company Name</label>
                        <input type="text" name="company" value="{{ $job->company }}">
                           <span style="color: red">
                                    @error('company')
                                        {{ $message }}
                                    @enderror
                                </span><br>
                        <label for="">Job Title</label>
                        <input type="text" name="title" value="{{ $job->title }}">
                           <span style="color: red">
                                    @error('title')
                                        {{ $message }}
                                    @enderror
                                </span><br>
                        <label for="">Position</label>
                        <input type="text" name="position" value="{{ $job->position }}">
                           <span style="color: red">
                                    @error('position')
                                        {{ $message }}
                                    @enderror
                                </span><br>
                       
                        <button style="width:100%;" type="submit" class="mt-4 btn btn-success btn-sm">Save information</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
</body>
</html>