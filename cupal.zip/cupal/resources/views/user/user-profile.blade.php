<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Basic</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-basic.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-batch.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-profile.css') }}">
</head>
<body>

    <div class="bg">
                
    </div>

    <div class="container-all">
        <div class="wrapper">
            <div class="form-con">
                <a href="{{ route('user-home') }}"><i class="fa-regular fa-circle-xmark hehahe"></i></a>
                <!-- <div class="profile-img">
                    <p class="p6">Profile picture</p>
                    <img class="img2" src="{{ asset('image/banner.jpg') }}" alt=""> 
                </div> -->
                <div class="con">
                    <form method="POST" action="{{ route('user-uploadProfile') }}" enctype="multipart/form-data">
                        @csrf
                        <input type="file" name="photo">
                        <span style="color: red">
                            @error('photo')
                                {{ $message }}
                            @enderror
                        </span><br>
                        <button style="width:100%;" type="submit" class="mt-4 btn btn-success btn-sm">Save information</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
</body>
</html>