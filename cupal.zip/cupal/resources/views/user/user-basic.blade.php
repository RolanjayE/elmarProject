<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Basic</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-batch.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-basic.css') }}">
</head>
<body>

    <div class="bg">
                
    </div>

    <div class="container-all">
        <div class="wrapper">
            <div class="form-con">
                <a href="{{ route('user-home') }}"><i class="fa-regular fa-circle-xmark hehahe"></i></a>
                <p class="p6">Basic information</p>
                <div class="con">
                    <form action="">
                        <label for="">First name</label>
                        <input type="text" placeholder="Ex. Juan" name="firstname">
                        <label for="">Middle name</label>
                        <input type="text" placeholder="Ex. Gwapo" name="lastname">
                        <label for="">Last name</label>
                        <input type="text" placeholder="Ex. Koh" name="middlename">
                        

                        <div class="flex">
                            <div class="f-box">
                                <label for="">Gender</label>
                                <select name="gender" id="">
                                    <option value="">Male</option>
                                    <option value="">Female</option>
                                </select>
                            </div>
                            <div class="f-box">
                                <label for="">Status</label>
                                <select name="stats" id="">
                                    <option value="">Single</option>
                                    <option value="">Married</option>
                                </select>
                            </div>
                        </div>

                        <label for="">Birth</label>
                        <input type="date" placeholder="Koh" name="birth">

                        <button style="width:100%;" type="submit" class="mt-4 btn btn-success">Save information</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
</body>
</html>