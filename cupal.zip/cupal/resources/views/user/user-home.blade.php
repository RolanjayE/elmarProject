<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-home.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script>
    $(document).ready(function(){
    $(".menu1").click(function(){
        $(".shows").toggle();
    });
    });
    </script>


        <div class="homeUser">

            <div class="headHome">
                
                <i class="menu1 fa-solid fa-bars mt-4"></i>
                <img style="width:40px; height: 40px; border-radius: 100%" src="{{ asset('image/logo.png') }}" alt="">
                <p>GCC Online Alumni Profilling System</p>

            </div>

            <div class="mainHomeContent">

                <div class="homeLeft shows">
                    <ul>
                        @if($contact === null) 
                            <li><a href="{{ route('user-contact') }}"><i class="fa-solid fa-address-book"></i> Contact</a></li>
                        @else
                            <li><a href="#contact"><i class="fa-solid fa-address-book"></i> Contact</a></li>
                        @endif

                        @if($job === null) 
                            <li><a href="{{ route('user-employment') }}"><i class="fa-solid fa-user-doctor"></i> Employment</a></li>
                        @else
                            <li><a href="#Employment"><i class="fa-solid fa-user-doctor"></i> Employment</a></li>
                        @endif

                        @if($ask === null) 
                            <li><a href="{{ route('user-updateask') }}"><i class="fa-solid fa-question"></i> Ask</a></li>
                        @else
                            <li><a href="#Ask"><i class="fa-solid fa-question"></i> Ask</a></li>
                        @endif

                        @if($education === null) 
                            <li><a href="{{ route('user-education') }}"><i class="fa-solid fa-school"></i> Education</a></li>
                        @else
                            <li><a href="#Education"><i class="fa-solid fa-school"></i> Education</a></li>
                        @endif
                        <li><a href="{{ route('user-eventUser') }}"><i class="fa-solid fa-calendar-days"></i> Events</a></li>
                        <li><a href="{{ route('user-batch')  }}"><i class="fa-solid fa-users"></i> Batch</a></li>
                        <li><a class="red" style="color: white;" href="{{ route('logout') }}"><i class="fa-solid fa-right-from-bracket"></i> logout</a></li>
                    </ul>
                </div>

                <div class="home-right">
                    <div class="homeWrapper">
                        
                        <div class="section-one">
                            <div class="wrapper secFlex">
                                <div class="profile">
                                    <!-- <i class="menu1 fa-solid fa-bars"></i> -->
                                    <div class="profile-img">
                                        @if($profile->profile !== "n/a")
                                            <img class="img2" src="{{ asset('storage/photos/' . $profile->profile) }}" alt="Profile Photo">
                                        @else 
                                            <img class="img2" src="{{ asset('image/banner.jpg') }}" alt=""> 
                                        @endif
                                </div>
                                    <div class="profile-info">
                                        <p class="p1">Student Of Gingoog City Colleges</p>
                                        <p class="p3"> {{ $profile->firstname }} {{ $profile->lastname }} </p>
                                        <a href="{{ route('user-profile') }}" class="btn btn-success btn-sm ">Profile</a>
                                        <a href="{{ route('user-settings') }}" class="btn btn-success btn-sm">Settings</a>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="section-two">
                            <div class="wrapper">
                                @if(session('success'))
                                        <div class="alert alert-success">
                                            {{ session('success') }}
                                        </div>
                                    @endif
                                <div class="all-container basic-info">
                                    <p class="p1">Basic information</p>
                                    <a href="{{ route('user-updatebasic') }}" class="btn btn-success btn-sm">Update</a>
                                    <div class="data-container">
                                        <div class="box">
                                            <p class="p4">Firstname</p>
                                            <p class="p7">{{ $profile->firstname }}</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Lastname</p>
                                            <p class="p7">{{ $profile->lastname }}</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Middlename</p>
                                            <p class="p7">{{ $profile->middlename }}</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Gender</p>
                                            <p class="p7">{{ $profile->gender }}</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Birth date</p>
                                            <p class="p7">{{ $profile->birth }}</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">status</p>
                                            <p class="p7">{{ $profile->stats }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

    
                        @if($contact !== null) 
                        <div class="section-three" id="contact">
                            <div class="wrapper">
                                <div class="all-container">
                                    <p class="p1">Contact information</p>
                                    <a href="{{ route('user-updatecontact') }}" class="btn btn-success btn-sm">Update</a>
                                    <div class="data-container">
                                        <div class="box">
                                            <p class="p4">Gmail</p>
                                            <p class="p7">{{ $contact->gmail }}</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Street Address</p>
                                            <p class="p7">{{ $contact->street }}</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">City</p>
                                            <p class="p7">{{ $contact->city }}</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">State/Province</p>
                                            <p class="p7">{{ $contact->state }}</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Postal Code/ZIP Code:</p>
                                            <p class="p7">{{ $contact->postal }}</p>
                                        </div>
                                    </div>
                                
                                </div>
                            </div>
                        </div>
                        @endif
    
                        @if($job !== null) 
                            <div class="section-four" id="Employment">
                                <div class="wrapper">
                                    <div class="all-container">
                                        <p class="p1">Employment History</p>
                                        <a href="{{ route('user-listemployment') }}" class="btn btn-success btn-sm">View</a>
                                        <div class="data-container">
                                            <div class="box">
                                                <p class="p4">Company Name</p>
                                                <p class="p7">{{ $job->company }}</p>
                                            </div>
                                            <div class="box">
                                                <p class="p4">Job Title</p>
                                                <p class="p7">{{ $job->title }}</p>
                                            </div>
                                            <div class="box">
                                                <p class="p4">Position</p>
                                                <p class="p7">{{ $job->position }}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif

                        @if($education !== null) 
                        <div class="section-five" id="Education">
                            <div class="wrapper">
                                <div class="all-container">
                                    <p class="p1">Education</p>
                                    <a href="{{ route('user-updateeducation') }}" class="btn btn-success btn-sm">Update</a>
                                    <div class="data-container">
                                        <div class="box">
                                            <p class="p4">Elementary education</p>
                                            <p class="p7">{{ $education->elem }}</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Year graduated</p>
                                            <p class="p7">{{ $education->yearElem }}</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">High School education</p>
                                            <p class="p7">{{ $education->highSchool }}</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Year graduated</p>
                                            <p class="p7">{{ $education->yearhighSchool }}</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Senior high School education</p>
                                            <p class="p7">{{ $education->senior }}</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Year graduated</p>
                                            <p class="p7">{{ $education->YearSenior }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif

                        <div class="section-six">
                            <div class="wrapper">
                                <div class="all-container">
                                    <p class="p1">Graduated</p>
                                    <a href="{{ route('user-gccTwo') }}" class="btn btn-success btn-sm">Update</a>
                                    <div class="data-container">
                                        <div class="box">
                                            <p class="p4">School name</p>
                                            <p class="p7">Gingoog City colleges</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Course</p>
                                            <p class="p7">{{ $course->course }}</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Date of Graduation</p>
                                            <p class="p7">{{ $profile->yearG }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        @if($ask !== null) 
                        <div class="section-seven" id="Ask">
                            <div class="wrapper">
                                <div class="all-container">
                                    <p class="p1">Question</p>
                                    <a href="{{ route('user-updateask') }}" class="btn btn-success btn-sm">Update</a>
                                    <div class="data-container">
                                        <div class="box">
                                            <p class="p4">Do you have a jobs ?</p>
                                            <p class="p7">{{ $ask->job }}</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Is your job related to the course you graduated in gingoog city colleges ?</p>
                                            <p class="p7">{{ $ask->related }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif   

                    </div>
                </div>
            </div>
        </div>

      


</body>
</html>