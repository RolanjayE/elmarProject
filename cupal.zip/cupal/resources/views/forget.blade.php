<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('global/login.css') }}">
    


</head>
<body>
    

    <div class="login-container">
       <div class="login-wrapper">
            <div class="login">


                <div class="huhu">
                    <!-- <h1>Hello Welcome</h1>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque officiis non excepturi inventore dolores ab animi magni illum error deserunt?</p> -->
                </div>

                <div class="hehe">
                    <div class="form-header">
                        <div class="headImg">
                            <img class="img1" src="{{ asset('image/heCute.png') }}" alt=""> 
                        </div>
                        <div class="lbox mt-1">
                            <p>Welcome to</p>
                            <p class="p11 mb-3">Gcc Online Alumni Profiling System</p>
                        </div>
                    </div>

                    <form action="{{ route('sendPlainTextEmail') }}" method="post">
                        @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif

                        @csrf
                        <label>Gmail</label>
                        <input class="mb-3" type="text" name="username" value="{{ old('username') }}">
                        <span style="color: red">@error('username'){{ $message }} @enderror</span>
                        <a class="mt-4" href="{{ route('login') }}">Already an account ?</a>
                        <button class="btn btn-primary mt-2" type="submit">Login</button>
                    </form>

                </div>

            </div>
       </div>
    </div>


</body>
</html>