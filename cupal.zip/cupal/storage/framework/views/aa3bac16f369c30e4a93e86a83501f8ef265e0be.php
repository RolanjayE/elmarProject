<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <?php if (isset($component)) { $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda = $component; } ?>
<?php $component = App\View\Components\GlobalHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('globalHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GlobalHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda)): ?>
<?php $component = $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda; ?>
<?php unset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('global/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/user-home.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script>
    $(document).ready(function(){
    $(".menu1").click(function(){
        $(".shows").toggle();
    });
    });
    </script>


        <div class="homeUser">

            <div class="headHome">
                
                <i class="menu1 fa-solid fa-bars mt-4"></i>
                <img style="width:40px; height: 40px; border-radius: 100%" src="<?php echo e(asset('image/logo.png')); ?>" alt="">
                <p>GCC Online Alumni Profilling System</p>

            </div>

            <div class="mainHomeContent">

                <div class="homeLeft shows">
                    <ul>
                        <?php if($contact === null): ?> 
                            <li><a href="<?php echo e(route('user-contact')); ?>"><i class="fa-solid fa-address-book"></i> Contact</a></li>
                        <?php else: ?>
                            <li><a href="#contact"><i class="fa-solid fa-address-book"></i> Contact</a></li>
                        <?php endif; ?>

                        <?php if($job === null): ?> 
                            <li><a href="<?php echo e(route('user-employment')); ?>"><i class="fa-solid fa-user-doctor"></i> Employment</a></li>
                        <?php else: ?>
                            <li><a href="#Employment"><i class="fa-solid fa-user-doctor"></i> Employment</a></li>
                        <?php endif; ?>

                        <?php if($ask === null): ?> 
                            <li><a href="<?php echo e(route('user-updateask')); ?>"><i class="fa-solid fa-question"></i> Ask</a></li>
                        <?php else: ?>
                            <li><a href="#Ask"><i class="fa-solid fa-question"></i> Ask</a></li>
                        <?php endif; ?>

                        <?php if($education === null): ?> 
                            <li><a href="<?php echo e(route('user-education')); ?>"><i class="fa-solid fa-school"></i> Education</a></li>
                        <?php else: ?>
                            <li><a href="#Education"><i class="fa-solid fa-school"></i> Education</a></li>
                        <?php endif; ?>
                        <li><a href="<?php echo e(route('user-eventUser')); ?>"><i class="fa-solid fa-calendar-days"></i> Events</a></li>
                        <li><a href="<?php echo e(route('user-batch')); ?>"><i class="fa-solid fa-users"></i> Batch</a></li>
                        <li><a class="red" style="color: white;" href="<?php echo e(route('logout')); ?>"><i class="fa-solid fa-right-from-bracket"></i> logout</a></li>
                    </ul>
                </div>

                <div class="home-right">
                    <div class="homeWrapper">
                        
                        <div class="section-one">
                            <div class="wrapper secFlex">
                                <div class="profile">
                                    <!-- <i class="menu1 fa-solid fa-bars"></i> -->
                                    <div class="profile-img">
                                        <?php if($profile->profile !== "n/a"): ?>
                                            <img class="img2" src="<?php echo e(asset('storage/photos/' . $profile->profile)); ?>" alt="Profile Photo">
                                        <?php else: ?> 
                                            <img class="img2" src="<?php echo e(asset('image/banner.jpg')); ?>" alt=""> 
                                        <?php endif; ?>
                                </div>
                                    <div class="profile-info">
                                        <p class="p1">Student Of Gingoog City Colleges</p>
                                        <p class="p3"> <?php echo e($profile->firstname); ?> <?php echo e($profile->lastname); ?> </p>
                                        <a href="<?php echo e(route('user-profile')); ?>" class="btn btn-success btn-sm ">Profile</a>
                                        <a href="<?php echo e(route('user-settings')); ?>" class="btn btn-success btn-sm">Settings</a>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="section-two">
                            <div class="wrapper">
                                <?php if(session('success')): ?>
                                        <div class="alert alert-success">
                                            <?php echo e(session('success')); ?>

                                        </div>
                                    <?php endif; ?>
                                <div class="all-container basic-info">
                                    <p class="p1">Basic information</p>
                                    <a href="<?php echo e(route('user-updatebasic')); ?>" class="btn btn-success btn-sm">Update</a>
                                    <div class="data-container">
                                        <div class="box">
                                            <p class="p4">Firstname</p>
                                            <p class="p7"><?php echo e($profile->firstname); ?></p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Lastname</p>
                                            <p class="p7"><?php echo e($profile->lastname); ?></p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Middlename</p>
                                            <p class="p7"><?php echo e($profile->middlename); ?></p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Gender</p>
                                            <p class="p7"><?php echo e($profile->gender); ?></p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Birth date</p>
                                            <p class="p7"><?php echo e($profile->birth); ?></p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">status</p>
                                            <p class="p7"><?php echo e($profile->stats); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

    
                        <?php if($contact !== null): ?> 
                        <div class="section-three" id="contact">
                            <div class="wrapper">
                                <div class="all-container">
                                    <p class="p1">Contact information</p>
                                    <a href="<?php echo e(route('user-updatecontact')); ?>" class="btn btn-success btn-sm">Update</a>
                                    <div class="data-container">
                                        <div class="box">
                                            <p class="p4">Gmail</p>
                                            <p class="p7"><?php echo e($contact->gmail); ?></p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Street Address</p>
                                            <p class="p7"><?php echo e($contact->street); ?></p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">City</p>
                                            <p class="p7"><?php echo e($contact->city); ?></p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">State/Province</p>
                                            <p class="p7"><?php echo e($contact->state); ?></p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Postal Code/ZIP Code:</p>
                                            <p class="p7"><?php echo e($contact->postal); ?></p>
                                        </div>
                                    </div>
                                
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
    
                        <?php if($job !== null): ?> 
                            <div class="section-four" id="Employment">
                                <div class="wrapper">
                                    <div class="all-container">
                                        <p class="p1">Employment History</p>
                                        <a href="<?php echo e(route('user-listemployment')); ?>" class="btn btn-success btn-sm">View</a>
                                        <div class="data-container">
                                            <div class="box">
                                                <p class="p4">Company Name</p>
                                                <p class="p7"><?php echo e($job->company); ?></p>
                                            </div>
                                            <div class="box">
                                                <p class="p4">Job Title</p>
                                                <p class="p7"><?php echo e($job->title); ?></p>
                                            </div>
                                            <div class="box">
                                                <p class="p4">Position</p>
                                                <p class="p7"><?php echo e($job->position); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if($education !== null): ?> 
                        <div class="section-five" id="Education">
                            <div class="wrapper">
                                <div class="all-container">
                                    <p class="p1">Education</p>
                                    <a href="<?php echo e(route('user-updateeducation')); ?>" class="btn btn-success btn-sm">Update</a>
                                    <div class="data-container">
                                        <div class="box">
                                            <p class="p4">Elementary education</p>
                                            <p class="p7"><?php echo e($education->elem); ?></p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Year graduated</p>
                                            <p class="p7"><?php echo e($education->yearElem); ?></p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">High School education</p>
                                            <p class="p7"><?php echo e($education->highSchool); ?></p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Year graduated</p>
                                            <p class="p7"><?php echo e($education->yearhighSchool); ?></p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Senior high School education</p>
                                            <p class="p7"><?php echo e($education->senior); ?></p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Year graduated</p>
                                            <p class="p7"><?php echo e($education->YearSenior); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="section-six">
                            <div class="wrapper">
                                <div class="all-container">
                                    <p class="p1">Graduated</p>
                                    <a href="<?php echo e(route('user-gccTwo')); ?>" class="btn btn-success btn-sm">Update</a>
                                    <div class="data-container">
                                        <div class="box">
                                            <p class="p4">School name</p>
                                            <p class="p7">Gingoog City colleges</p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Course</p>
                                            <p class="p7"><?php echo e($course->course); ?></p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Date of Graduation</p>
                                            <p class="p7"><?php echo e($profile->yearG); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php if($ask !== null): ?> 
                        <div class="section-seven" id="Ask">
                            <div class="wrapper">
                                <div class="all-container">
                                    <p class="p1">Question</p>
                                    <a href="<?php echo e(route('user-updateask')); ?>" class="btn btn-success btn-sm">Update</a>
                                    <div class="data-container">
                                        <div class="box">
                                            <p class="p4">Do you have a jobs ?</p>
                                            <p class="p7"><?php echo e($ask->job); ?></p>
                                        </div>
                                        <div class="box">
                                            <p class="p4">Is your job related to the course you graduated in gingoog city colleges ?</p>
                                            <p class="p7"><?php echo e($ask->related); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>   

                    </div>
                </div>
            </div>
        </div>

      


</body>
</html><?php /**PATH C:\cupal\resources\views/user/user-home.blade.php ENDPATH**/ ?>