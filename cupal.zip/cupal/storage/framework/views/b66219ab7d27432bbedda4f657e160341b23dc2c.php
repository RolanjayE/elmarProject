<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <?php if (isset($component)) { $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda = $component; } ?>
<?php $component = App\View\Components\GlobalHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('globalHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GlobalHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda)): ?>
<?php $component = $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda; ?>
<?php unset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('global/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/admin-home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/admin-profile.css')); ?>">

</head>
<body>
    

<div class="mainADmin">
        <div class="sideLeft">
            
            <ul>
                <li><a href="<?php echo e(route('admin-home')); ?>">Main dashboard</a></li>
                <li><a  href="<?php echo e(route('admin-addCourse')); ?>">Add Course</a></li>
                <li><a  href="<?php echo e(route('admin-addUsers')); ?>">Add Users</a></li>
                <li><a href="<?php echo e(route('admin-eventAdmin')); ?>">Add Event</a></li>
                <li><a style="background-color: white; color: black;" href="<?php echo e(route('admin-course')); ?>">Profiles</a></li>
                <li><a href="<?php echo e(route('admin-jobs')); ?>">Jobs</a></li>
                <li><a href="<?php echo e(route('admin-report')); ?>">Report</a></li>
                <li><a href="<?php echo e(route('admin-account')); ?>">Settings</a></li>
                <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
            </ul>
        </div>
        <div class="sideRight">
            <div class="adminHeader">
                <i class="menu1 fa-solid fa-bars mt-4"></i>
            </div>

            <div class="allDataHere">
                <p class="p3 mb-4">Profiles</p>
                <p class="p6"><?php echo e($course->course); ?> <br> <span style="font-size: 22px;"><?php echo e($courseId); ?></span></p>
                
                <input style="color: black;" type="search" name="search" id="profileSearch" placeholder="Search name">
                <div class="profile-con" id="profileContainer">

                    <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="profile">
                            <?php if($profile->profile !== "n/a"): ?>
                                <img style="width: 100px; height: 100px;" src="<?php echo e(asset('storage/photos/' . $profile->profile)); ?>" alt="Profile Photo">
                            <?php else: ?> 
                                <img style="width: 100px; height: 100px;" src="<?php echo e(asset('image/banner.jpg')); ?>" alt=""> 
                            <?php endif; ?>
                        <div class="info">
                        <p class="p7"><?php echo e($profile->firstname); ?> <?php echo e($profile->lastname); ?> <?php echo e($profile->middlename); ?></p>
                            <p class="p7"></p>
                            <a class="btn btn-success btn-sm mt-3" href="<?php echo e(route('admin-personProfile', ['profileID' => $profile->userId])); ?>">View profile</a>
                        </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>


        </div>
    </div>


    
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var profileContainer = document.getElementById('profileContainer');
            var profileSearch = document.getElementById('profileSearch');

            profileSearch.addEventListener('input', function () {
                var searchTerm = profileSearch.value.toLowerCase();

                Array.from(profileContainer.getElementsByClassName('profile')).forEach(function (profile) {
                    var profileName = profile.querySelector('.p7').textContent.toLowerCase();

                    if (profileName.includes(searchTerm)) {
                        profile.style.display = 'flex';
                    } else {
                        profile.style.display = 'none';
                    }
                });
            });
        });
    </script>



</body>
</html><?php /**PATH C:\cupal\resources\views/admin/admin-yearBatch.blade.php ENDPATH**/ ?>