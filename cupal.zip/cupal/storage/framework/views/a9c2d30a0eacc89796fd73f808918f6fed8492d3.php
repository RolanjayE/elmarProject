<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jobs</title>
    <?php if (isset($component)) { $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda = $component; } ?>
<?php $component = App\View\Components\GlobalHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('globalHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GlobalHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda)): ?>
<?php $component = $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda; ?>
<?php unset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('global/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/admin-home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/admin-report.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('admin/admin-home.css')); ?>">
</head>
<body>
    <style>
       /* print-styles.css */
@media print {
    body {
        margin: 0; /* Reset margin */
        padding: 0; /* Reset padding */
    }

    h1 {
        text-align: center; /* Center the title */
    }

    table {
        margin: 0 auto; /* Center the table horizontally */
        width: 80%; /* Adjust the width of the table as needed */
        border-collapse: collapse; /* Optional: Collapse table borders */
    }

    th, td {
        border: 1px solid #000; /* Optional: Add borders to table cells */
        padding: 8px; /* Optional: Add padding to table cells */
        text-align: left; /* Optional: Align text within cells */
    }

    @page {
        size: A4; /* Set the page size, adjust as needed */
        margin: 2cm; /* Set the page margins */
    }

    button {
        display: none; /* Hide the print button when printing */
    }
}

    </style>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawStuff);

      function drawStuff() {
        var data = new google.visualization.arrayToDataTable([
          ['Course', 'Employed', 'UnEmployed'],
          <?php $__currentLoopData = $courseCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseCount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            ['<?php echo e($courseCount->course); ?>', <?php echo e($courseCount->yes_count); ?>, <?php echo e($courseCount->no_count); ?>],    
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]);

        var options = {
          width: 1000,
          chart: {
            title: 'College Graduate Employment Status',
            subtitle: 'Summary of Graduated College Students Employment Outcomes'
          },
          bars: 'horizontal', // Required for Material Bar Charts.
          series: {
            0: { axis: 'distance' }, // Bind series 0 to an axis named 'distance'.
            1: { axis: 'brightness' } // Bind series 1 to an axis named 'brightness'.
          },
          axes: {
            x: {
              distance: {label: 'parsecs'}, // Bottom x-axis.
              brightness: {side: 'top', label: 'apparent magnitude'} // Top x-axis.
            }
          }
        };

      var chart = new google.charts.Bar(document.getElementById('dual_x_div'));
      chart.draw(data, options);
    };
    </script>

    <div class="mainADmin">
        <div class="sideLeft">
            
            <ul>
                <li><a style="background-color: white; color: black;" href="<?php echo e(route('admin-home')); ?>"><i class="fa-solid fa-gauge"></i> Main dashboard</a></li>
                <li><a href="<?php echo e(route('admin-addCourse')); ?>"><i class="fa-solid fa-folder"></i>  Add Course</a></li>
                <li><a href="<?php echo e(route('admin-addUsers')); ?>"><i class="fa-solid fa-user"></i> Add Users</a></li>
                <li><a href="<?php echo e(route('admin-eventAdmin')); ?>"><i class="fa-solid fa-calendar-days"></i> Add Event</a></li>
                <li><a href="<?php echo e(route('admin-course')); ?>"><i class="fa-regular fa-address-card"></i> Profiles</a></li>
                <li><a style="background-color: white; color: black;" href="<?php echo e(route('admin-jobs')); ?>"><i class="fa-solid fa-chart-simple"></i> Jobs</a></li>
                <li><a href="<?php echo e(route('admin-report')); ?>"><i class="fa-solid fa-chart-simple"></i> Report</a></li>
                <li><a href="<?php echo e(route('admin-account')); ?>"><i class="fa-solid fa-gears"></i> Settings</a></li>
                <li><a href="<?php echo e(route('logout')); ?>"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
            </ul>
        </div>
        <div class="sideRight">
            <div class="adminHeader">
                <i class="menu1 fa-solid fa-bars mt-4"></i>
            </div>

            <div class="allDataHere">
                <p class="p3 mb-4">Jobs</p>
                <div class="table-jobs">
                    <div class="job-grapth">
                        <div id="dual_x_div" style="width: 100%; height: 350px;"></div>
                    </div>
                    <button class="btn btn-primary btn-sm mb-2" onclick="printTable()">Print Table</button>
                    <table id="yourTableId">
                        <tr>
                            <th>Course</th>
                            <th>Yes I Have a Job</th>
                            <th>No I Dont Have a Jobs</th>
                        </tr>

                        <?php $__currentLoopData = $courseCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseCount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($courseCount->course); ?></td>
                                <td><?php echo e($courseCount->yes_count); ?></td>
                                <td><?php echo e($courseCount->no_count); ?></td>
                            </tr>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>


        </div>
    </div>



    <script>
    function printTable() {
            var printWindow = window.open('', '_blank');
            printWindow.document.write('<html><head><title>Table Printing</title>');
            printWindow.document.write('<link rel="stylesheet" href="path/to/print-styles.css" type="text/css" media="print">');
            printWindow.document.write('</head><body>');
            printWindow.document.write('<h3>Summary of Graduated College Students Employment Outcomes</h3>');
            printWindow.document.write(document.getElementById('yourTableId').outerHTML);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        }

</script>


</body>
</html><?php /**PATH C:\cupal\resources\views/admin/admin-jobs.blade.php ENDPATH**/ ?>