<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bacth</title>
    <?php if (isset($component)) { $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda = $component; } ?>
<?php $component = App\View\Components\GlobalHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('globalHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GlobalHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda)): ?>
<?php $component = $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda; ?>
<?php unset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('global/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/admin-home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/admin-profile.css')); ?>">

</head>
<body>


<div class="mainADmin">
        <div class="sideLeft">
            
            <ul>
                <li><a href="<?php echo e(route('admin-home')); ?>">Main dashboard</a></li>
                <li><a  href="<?php echo e(route('admin-addCourse')); ?>">Add Course</a></li>
                <li><a  href="<?php echo e(route('admin-addUsers')); ?>">Add Users</a></li>
                <li><a href="<?php echo e(route('admin-eventAdmin')); ?>">Add Event</a></li>
                <li><a style="background-color: white; color: black;" href="<?php echo e(route('admin-course')); ?>">Profiles</a></li>
                <li><a href="<?php echo e(route('admin-jobs')); ?>">Jobs</a></li>
                <li><a href="<?php echo e(route('admin-report')); ?>">Report</a></li>
                <li><a href="<?php echo e(route('admin-account')); ?>">Settings</a></li>
                <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
            </ul>
        </div>
        <div class="sideRight">
            <div class="adminHeader">
                <i class="menu1 fa-solid fa-bars mt-4"></i>
            </div>

            <div class="allDataHere">
                <p class="p3 mb-4">Profiles</p>
                <p class="p6"><?php echo e($coursename); ?></p>
                <div class="wrapper1 choy">
                    <?php $__currentLoopData = $uniqueYearGValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uniqueYearGValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button><a href="<?php echo e(route('admin-yearBatch', ['year' => $courseId, 'courseId' => $uniqueYearGValue] )); ?>"><?php echo e($uniqueYearGValue); ?></a></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
     
            </div>


        </div>
    </div>

    <!-- <div class="adminHeadHead">
            <div class="wrapper1">
                    <a style="color: gold;"  href="<?php echo e(route('admin-home')); ?>">Main dashboard</a>
                    <a href="<?php echo e(route('admin-addCourse')); ?>">Add Course</a>
                    <a href="<?php echo e(route('admin-addUsers')); ?>">Add Users</a>
                    <a href="<?php echo e(route('admin-course')); ?>">Profiles</a>
                    <a href="<?php echo e(route('admin-jobs')); ?>">Jobs</a>
                    <a href="<?php echo e(route('admin-report')); ?>">Report</a>
                    <a href="<?php echo e(route('admin-account')); ?>">Settings</a>
                    <a class="cutee btn btn-danger" style="float:right" href="<?php echo e(route('logout')); ?>">Logout</a>
            </div>
    </div>
    

    <div class="course-container">
        <div class="wrapper1 choy">
            
            <p class="p6"><?php echo e($coursename); ?></p>

           <?php $__currentLoopData = $uniqueYearGValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uniqueYearGValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button><a href="<?php echo e(route('admin-yearBatch', ['year' => $courseId, 'courseId' => $uniqueYearGValue] )); ?>"><?php echo e($uniqueYearGValue); ?></a></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
                
        </div>
    </div> -->

</body>
</html><?php /**PATH C:\cupal\resources\views/admin/admin-batch.blade.php ENDPATH**/ ?>