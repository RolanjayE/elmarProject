<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User list</title>
    <?php if (isset($component)) { $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda = $component; } ?>
<?php $component = App\View\Components\GlobalHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('globalHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GlobalHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda)): ?>
<?php $component = $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda; ?>
<?php unset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('global/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/admin-addCourse.css')); ?>">
</head>
<body>

<div class="bg">

    </div>

    <div class="addContainer">
        <div class="wrapper">
            <a href="<?php echo e(route('admin-home')); ?>" class="btn btn-primary mb-4">Back</a>
            <div class="add">
                <input type="search" placeholder="Search" class="mb-2">
               <table>
                    <tr>
                        <th>Username</th>
                        <th>Operation</th>
                    </tr>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->username); ?></td>
                        <td style="display: flex; gap:10px">
                            <a href="<?php echo e(route('admin-deleteUser', ['id' => $user->id ])); ?>" style="font-size: 11px" class="btn btn-danger">Delete </a>
                            <a href="<?php echo e(route('admin-userUpdate', ['id' => $user->id ])); ?>" style="font-size: 11px" class="btn btn-primary">Update</a>
                        </td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </table>
            </div>
        </div>
    </div>
    
</body>
</html><?php /**PATH C:\cupal\resources\views/admin/admin-userList.blade.php ENDPATH**/ ?>