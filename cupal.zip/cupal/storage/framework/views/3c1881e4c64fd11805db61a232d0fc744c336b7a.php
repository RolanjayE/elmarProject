<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php if (isset($component)) { $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda = $component; } ?>
<?php $component = App\View\Components\GlobalHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('globalHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GlobalHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda)): ?>
<?php $component = $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda; ?>
<?php unset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('user/user-event.css')); ?>">
    <title>Event</title>
</head>
<body>



    <div class="headerMain">
        <div class="headEvent">
            <div class="eventleft">
                <div class="lebox">
                    <input type="search" placeholder="Search" id="searchInput" oninput="searchEvents()">
                </div>
                <div>
                    <div class="lebox"><a href="<?php echo e(route('user-home')); ?>">Home</a></div>
                </div>
            </div>
        </div>
        <div class="header-wrapper">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="header-box mb-2 event-item">
                    <div class="content-info">
                        <p class="p11">Date started: <span><?php echo e(\Carbon\Carbon::parse($event->started)->format('F j, Y')); ?></span></p>
                        <p class="p11">Date Ended: <span><?php echo e(\Carbon\Carbon::parse($event->end)->format('F j, Y')); ?></span></p>
                        <p class="decrip"><?php echo e($event->desc); ?></p>
                    </div>
                    <div class="content-img">
                        <img class="img2" src="<?php echo e(asset('storage/photos/' . $event->photo)); ?>" alt="Profile Photo">
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <script>
    function searchEvents() {
        var input, filter, events, eventItem, i, txtValue;
        input = document.getElementById("searchInput");
        filter = input.value.toUpperCase();
        events = document.getElementsByClassName("event-item");

        for (i = 0; i < events.length; i++) {
            eventItem = events[i];
            txtValue = eventItem.innerText || eventItem.textContent;
            
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                eventItem.style.display = "";
            } else {
                eventItem.style.display = "none";
            }
        }
    }
</script>
    
</body>
</html><?php /**PATH C:\cupal\resources\views/user/user-eventUser.blade.php ENDPATH**/ ?>