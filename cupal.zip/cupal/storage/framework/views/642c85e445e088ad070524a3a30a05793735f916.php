<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <?php if (isset($component)) { $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda = $component; } ?>
<?php $component = App\View\Components\GlobalHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('globalHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GlobalHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda)): ?>
<?php $component = $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda; ?>
<?php unset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('global/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('global/login.css')); ?>">
    


</head>
<body>
    

    <div class="login-container">
       <div class="login-wrapper">
            <div class="login">


                <div class="huhu">
                    <!-- <h1>Hello Welcome</h1>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque officiis non excepturi inventore dolores ab animi magni illum error deserunt?</p> -->
                </div>

                <div class="hehe">
                    <div class="form-header">
                        <div class="headImg">
                            <img class="img1" src="<?php echo e(asset('image/heCute.png')); ?>" alt=""> 
                        </div>
                        <div class="lbox mt-1">
                            <p>Welcome to</p>
                            <p class="p11 mb-3">Gcc Online Alumni Profiling System</p>
                        </div>
                    </div>

                    <form action="<?php echo e(route('sendPlainTextEmail')); ?>" method="post">
                        <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>

                        <?php echo csrf_field(); ?>
                        <label>Gmail</label>
                        <input class="mb-3" type="text" name="username" value="<?php echo e(old('username')); ?>">
                        <span style="color: red"><?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        <a class="mt-4" href="<?php echo e(route('login')); ?>">Already an account ?</a>
                        <button class="btn btn-primary mt-2" type="submit">Login</button>
                    </form>

                </div>

            </div>
       </div>
    </div>


</body>
</html><?php /**PATH C:\cupal\resources\views/forget.blade.php ENDPATH**/ ?>