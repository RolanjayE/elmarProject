<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course</title>
    <?php if (isset($component)) { $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda = $component; } ?>
<?php $component = App\View\Components\GlobalHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('globalHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GlobalHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda)): ?>
<?php $component = $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda; ?>
<?php unset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('global/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/admin-person.css')); ?>">

</head>
<body>
    

    <div class="course-container">
        <div class="wrapper1">
            <a style="float: right;" href="<?php echo e(route('admin-course')); ?>">back</a>
            <div class="person">
               <!-- <h1><?php echo e($profileID); ?></h1> -->
               <div class="leftt">
                    <?php if($profiles->profile !== "n/a"): ?>
                        <img style="border-radius: 100%; width: 200px; height: 200px;" src="<?php echo e(asset('storage/photos/' . $profiles->profile)); ?>" alt="Profile Photo">
                    <?php else: ?>
                        <img style="border-radius: 100%; width: 200px; height: 200px;" class="img2" src="<?php echo e(asset('image/banner.jpg')); ?>" alt=""> 
                    <?php endif; ?>
                </div>
               <div class="rightt">
                    <!-- person profile -->
                   <div class="information">
                        <p>Personal Information</p>
                        <div class="user-table">
                            <div class="header">Firstname:</div>
                            <div class="data"><?php echo e($profiles->firstname); ?></div>
                        </div>
                        <div class="user-table">
                            <div class="header">Lastname:</div>
                            <div class="data"><?php echo e($profiles->lastname); ?></div>
                        </div>
                        <div class="user-table">
                            <div class="header">Middlename:</div>
                            <div class="data"><?php echo e($profiles->middlename); ?></div>
                        </div>
                        <div class="user-table">
                            <div class="header">Gender:</div>
                            <div class="data"><?php echo e($profiles->gender); ?></div>
                        </div>
                        <div class="user-table">
                            <div class="header">Status:</div>
                            <div class="data"><?php echo e($profiles->stats); ?></div>
                        </div>
                        <div class="user-table">
                            <div class="header">Birth:</div>
                            <div class="data"><?php echo e($profiles->birth); ?></div>
                        </div>
                   </div>
                <?php if($contact !== null): ?>
                   <div class="information">
                        <p class="mt-3">Contact information</p>
                        <div class="user-table">
                            <div class="header">Gmail</div>
                            <div class="data"><?php echo e($contact->gmail); ?></div>
                        </div>
                        <div class="user-table">
                            <div class="header">Street:</div>
                            <div class="data"><?php echo e($contact->street); ?></div>
                        </div>
                        <div class="user-table">
                            <div class="header">City:</div>
                            <div class="data"><?php echo e($contact->city); ?></div>
                        </div>
                        <div class="user-table">
                            <div class="header">State:</div>
                            <div class="data"><?php echo e($contact->state); ?></div>
                        </div>
                   </div>
                <?php endif; ?>

                <?php if($education !== null): ?>
                   <div class="information">
                        <p class="mt-3">Education</p>
                        <div class="user-table">
                            <div class="header">Elementary Education</div>
                            <div class="data"><?php echo e($education->elem); ?></div>
                        </div>
                        <div class="user-table">
                            <div class="header">Elementary year graduted</div>
                            <div class="data"><?php echo e($education->yearElem); ?></div>
                        </div>
                        <div class="user-table">
                            <div class="header">High school education</div>
                            <div class="data"><?php echo e($education->highSchool); ?></div>
                        </div>
                        <div class="user-table">
                            <div class="header">High school year gradute</div>
                            <div class="data"><?php echo e($education->yearhighSchool); ?></div>
                        </div>
                        <div class="user-table">
                            <div class="header">Senior High School</div>
                            <div class="data"><?php echo e($education->senior); ?></div>
                        </div>
                        <div class="user-table">
                            <div class="header">Senior High School year gradute</div>
                            <div class="data"><?php echo e($education->YearSenior); ?></div>
                        </div>
                   </div>
                <?php endif; ?>

                   <?php if($ask !== null): ?>
                    <div class="information">
                            <p class="mt-3">Question</p>
                            <div class="user-table">
                                <div class="header">Do you have jobs ? </div>
                                <div class="data"><?php echo e($ask->job); ?></div>
                            </div>
                            <div class="user-table">
                                <div class="header">Job related to the course ?</div>
                                <div class="data"><?php echo e($ask->related); ?></div>
                            </div>
                    </div>
                   <?php endif; ?>

                   <?php if($jobs !== null): ?>
                    <div class="informations">
                            <p class="mt-3">My Jobs history</p>
                            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="user-table">
                                    <div class="header">Company name </div>
                                    <div class="data"><?php echo e($job->company); ?></div>
                                </div>
                                <div class="user-table">
                                    <div class="header">Job title ?</div>
                                    <div class="data"><?php echo e($job->title); ?></div>
                                </div>
                                <div class="user-table heloow">
                                    <div class="header">Position </div>
                                    <div class="data"><?php echo e($job->position); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                   <?php endif; ?>


               </div>
            </div>
        </div>
    </div>

</body>
</html><?php /**PATH C:\cupal\resources\views/admin/admin-personProfile.blade.php ENDPATH**/ ?>