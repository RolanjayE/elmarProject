<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ask</title>
    <?php if (isset($component)) { $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda = $component; } ?>
<?php $component = App\View\Components\GlobalHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('globalHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GlobalHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda)): ?>
<?php $component = $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda; ?>
<?php unset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('global/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/user-basic.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/user-batch.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/user-ask.css')); ?>">
</head>
<body>

    <div class="bg">
                
    </div>

    <div class="container-all">
        <div class="wrapper">
            <div class="form-con">
                <a href="<?php echo e(route('user-home')); ?>"><i class="fa-regular fa-circle-xmark hehahe"></i></a>
                
                <div class="ask">
                    <form action="<?php echo e(route('user-addAsk')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label for="job">Do you have a job</label>
                        <select name="job" id="jobSelect">
                            <option value="" disabled>Select an option</option>
                            <option value="yes">Yes</option>
                            <option value="no">No</option>
                        </select>

                        <label for="related" id="relatedLabel" style="display: none;">Is your job related to the course you graduated in gingoog city colleges?</label>
                        <select name="related" id="relatedSelect" style="display: none;">
                            <option value="yes">Yes</option>
                            <option value="no">No</option>
                        </select>
                        <button style="width:100%;" type="submit" class="mt-4 btn btn-success btn-sm">Save information ?</button>
                    </form>
                </div>
                
            </div>
        </div>
    </div>
    

    <script>
        const jobSelect = document.getElementById("jobSelect");
        const relatedLabel = document.getElementById("relatedLabel");
        const relatedSelect = document.getElementById("relatedSelect");

        jobSelect.addEventListener("change", function() {
            if (jobSelect.value === "no") {
                relatedLabel.style.display = "none";
                relatedSelect.style.display = "none";
                relatedSelect.value = "no"; // Set the value of the second select to "no"
            } else {
                relatedLabel.style.display = "block";
                relatedSelect.style.display = "block";
            }
        });
    </script>

</body>
</html><?php /**PATH C:\cupal\resources\views/user/user-updateask.blade.php ENDPATH**/ ?>