<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Course</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

    <?php if (isset($component)) { $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda = $component; } ?>
<?php $component = App\View\Components\GlobalHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('globalHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GlobalHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda)): ?>
<?php $component = $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda; ?>
<?php unset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('global/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/admin-addCourse.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/admin-home.css')); ?>">
</head>
<body>

    <div class="mainADmin">
        <div class="sideLeft">
            
            <ul>
                <li><a href="<?php echo e(route('admin-home')); ?>"><i class="fa-solid fa-gauge"></i> Main dashboard</a></li>
                <li><a style="background-color: white; color: black;" href="<?php echo e(route('admin-addCourse')); ?>"><i class="fa-solid fa-folder"></i>  Add Course</a></li>
                <li><a href="<?php echo e(route('admin-addUsers')); ?>"><i class="fa-solid fa-user"></i> Add Users</a></li>
                <li><a href="<?php echo e(route('admin-eventAdmin')); ?>"><i class="fa-solid fa-calendar-days"></i> Add Event</a></li>
                <li><a href="<?php echo e(route('admin-course')); ?>"><i class="fa-regular fa-address-card"></i> Profiles</a></li>
                <li><a href="<?php echo e(route('admin-jobs')); ?>"><i class="fa-solid fa-chart-simple"></i> Jobs</a></li>
                <li><a href="<?php echo e(route('admin-report')); ?>"><i class="fa-solid fa-chart-simple"></i> Report</a></li>
                <li><a href="<?php echo e(route('admin-account')); ?>"><i class="fa-solid fa-gears"></i> Settings</a></li>
                <li><a href="<?php echo e(route('logout')); ?>"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
            </ul>
        </div>
        <div class="sideRight">
            <div class="adminHeader">
                <i class="menu1 fa-solid fa-bars mt-4"></i>
            </div>

            <div class="allDataHere">
                <p class="p3 mb-4">Course</p>
                <div class="formConta">
                    <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('admin-addCourses')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                        <label for="">Acronym</label>
                        <input style="text-transform: uppercase;" type="text" placeholder="" name="acronym">
                        <span style="color: red"><?php $__errorArgs = ['acronym'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span><br>
                        <label for="">Course name</label>
                        <input style="text-transform: uppercase;" type="text" placeholder="" name="cname">
                        <span style="color: red"><?php $__errorArgs = ['cname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span><br>
                        <button type="submit" class="mt-3 btn btn-success btn-sm">Save</button>
                    </form>
                </div>
                <div class="table mt-4">

                    <table id="example" class="table table-striped mt-2" style="width:100%">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Acronym</th>
                                <th>Operation</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($course->course); ?></td>
                                    <td><?php echo e($course->acronym); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin-courseDelete', ['id' => $course->id])); ?>" style="font-size: 11px" class="btn btn-danger btn-sm">Delete </a>
                                        <a href="<?php echo e(route('admin-courseUpdate', ['id' => $course->id])); ?>" style="font-size: 11px" class="btn btn-success btn-sm">Update </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Name</th>
                                <th>Acronym</th>
                                <th>Operation</th>
                            </tr>
                        </tfoot>
                    </table>

                </div>
            </div>


        </div>
    </div>

    <script>
        new DataTable('#example');
    </script>


</body>
</html><?php /**PATH C:\cupal\resources\views/admin/admin-addCourse.blade.php ENDPATH**/ ?>