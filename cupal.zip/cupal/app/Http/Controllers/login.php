<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\users;
use Hash;
use Illuminate\Support\Facades\Mail;

class login extends Controller
{
    //login
    public function login() {
        return view('login');
    }

    //login
    public function forget() {
        return view('forget');
    }


       //validateLogin get
    public function loginAuth(Request $request) {

        $request->validate([
            'username' => 'required',
            'passwords' => 'required',
        ]);
        
        // $user = users::where('username', '=', $request->username)->first();
        $user = users::where('username', $request->username)->first();

        if ($user && Hash::check($request->passwords, $user->password)) {

            if ($user->role === '1') {
                session(['user_role' => 'admin']);
                session(['users' => $user]);
                return redirect()->route('admin-home');
            } elseif( $user->role === '0' ) {
                session(['user_role' => 'user']);
                session(['users' => $user]);
                return redirect()->route('user-gcc');
            }

        } else {
            return redirect()->route('login');
        }

        
    }


    
    public function logout() {
        session()->forget('user_role');
        session()->forget('user');
        // Perform other logout actions
        return redirect()->route('login');
    }



 

    public function sendPlainTextEmail(Request $request)
    {
        // $recipientEmail = 'rolanjayisabida46@gmail.com';
        // $subject = 'Hello World';
        // $message = 'Hello, this is a plain text email!';

        // Mail::raw($message, function ($mail) use ($recipientEmail, $subject) {
        //     $mail->to($recipientEmail)
        //         ->from('your@example.com', 'Your Name') // Add the sender's email and name
        //         ->subject($subject);
        // });

        // return 'Plain text email sent successfully!';

        dd($request->all());
    }



    
}
