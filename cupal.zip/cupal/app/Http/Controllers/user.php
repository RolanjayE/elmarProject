<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\course;
use App\Models\profile;
use App\Models\contact;
use App\Models\education;
use App\Models\ask;
use App\Models\job;
use App\Models\event;
use App\Models\users;
use Hash;

class user extends Controller
{
     //home
     public function home() {
        $profile = profile::where('userId', session('users')->id)->first();
        $course = course::where('id', $profile->userIdCourse)->first();
        $contact = contact::where('userId', session('users')->id)->first();
        $education = education::where('userId', session('users')->id)->first();
        $ask = ask::where('userId', session('users')->id)->first();
        $job = job::where('userId', session('users')->id)->first();
        return view('user/user-home', compact('profile', 'contact', 'education', 'ask', 'job', 'course'));
     }
     
    //basic
    public function basic() {
        return view('user/user-basic');
    }

    public function settings() {
        return view('user/user-settings');
    }

      //updatebasic
    public function updatebasic() {
        $profile = profile::where('userId', session('users')->id)->first();
        return view('user/user-updatebasic', compact('profile'));
    }


     //basic
     public function contact() {
        
        return view('user/user-contact');
    }

      //updatecontact
    public function updatecontact() {
        $contact = contact::where('userId', session('users')->id)->first();
        return view('user/user-updatecontact', compact('contact'));
    }

      //profile
      public function profile() {
        return view('user/user-profile');
    }

       //updateemployment
    public function employment() {
        return view('user/user-employment');
    }

    //listemployment
    public function listemployment() {
        // $jobs = job::all();
        $jobs = job::where('userId', session('users')->id)->get();
        return view('user/user-listemployment', compact('jobs'));
    }

       //updateemployment
    public function updateemployment($answer) {
        $job = job::where('id', $answer)->first();
        return view('user/user-updateemployment', compact('answer', 'job'));

    }
    
    //ask
    public function ask() {
        return view('user/user-ask');
    }

     //updateask
     public function updateask() {
        return view('user/user-updateask');
    }

    //education
    public function education() {
        return view('user/user-education');
    }

    //updateeducation
    public function updateeducation() {
        $education = education::where('userId', session('users')->id)->first();
        return view('user/user-updateeducation', compact('education'));
    }

      //gradute
    public function gradute() {
        return view('user/user-gradute');
    }

      //listgradute
      public function listgradute() {
        return view('user/user-listgradute');
    }

       //updategradute
    public function updategradute() {
        return view('user/user-updategradute');
    }


    //updategradute
    public function eventUser() {
        $events = event::all();
        return view('user/user-eventUser', compact('events'));
    }
    //updategradute
    public function batch() {
        $profile = profile::where('userId', session('users')->id)->first();
        $courses = profile::where('userIdCourse', $profile->userIdCourse)->get();
        // dd($courses);
        return view('user/user-batch', compact('courses', 'profile'));
    }


    //updategradute
    public function gcc() {
        $courses = Course::all();
        $profile = profile::where('userId', session('users')->id)->first();
        if($profile === null) {
            return view('user/user-gcc', compact('courses'));
        } else {
            return redirect()->route('user-home');
        }

    }

    public function gccTwo() {
        $courses = Course::all();
        return view('user/user-gcc2', compact('courses'));

    }



    public function addProfileBasic(Request $request ){
        $request->validate([
            'year' => 'required',
            'courseID' => 'required',
        ]);

        $profile = new profile();
        $profile->firstname  = "n/a";
        $profile->lastname   = "n/a";
        $profile->middlename = "n/a";
        $profile->gender     = "n/a";
        $profile->stats      = "n/a";
        $profile->birth      = "n/a";
        $profile->profile    = "n/a";
        $profile->status     = 0;

        $profile->yearG        = $request->year;
        $profile->userIdCourse =  $request->courseID;
        $profile->userId       = session('users')->id;
        $profile->save();
        return redirect()->route('user-home')->with('success', 'Data has been updated.');

    }


    public function updateAddProfileBasic(Request $request ) {
        $request->validate([
            'year' => 'required|regex:/^\d{4}$/',
            'courseID' => 'required',
        ]);

        $profile = profile::where('userId', session('users')->id)->first();
        if($profile !== null) {
            $profile->yearG        = $request->year;
            $profile->userIdCourse =  $request->courseID;
            $profile->save();
            return redirect()->route('user-home')->with('success', 'Data has been updated.');
        }
       
    }



    public function addBasic(Request $request ){
        $request->validate([
            "firstname" => "required",
            "lastname" => "required",
            "middlename" => "required",
            "gender" => "required",
            "stats" => "required",
            "birth" => "required",
        ]);

        $profile = profile::where('userId', session('users')->id)->first();
        if($profile !== null) {
            $profile->firstname  = $request->firstname;
            $profile->lastname   = $request->lastname;
            $profile->middlename = $request->middlename;
            $profile->gender     = $request->gender;
            $profile->stats      = $request->stats;
            $profile->birth      = $request->birth;
            $profile->save();
            return redirect()->route('user-home')->with('success', 'Data has been updated.');
        }

    }


    public function addContact(Request $request ){
        $request->validate([
            "gmail" => "required",
            "street" => "required",
            "city" => "required",
            "state" => "required",
            "postal" => "required",
        ]);

        $contact = contact::where('userId', session('users')->id)->first();
        if($contact !== null) {
            $contact->gmail    = $request->gmail;
            $contact->street   = $request->street;
            $contact->city     = $request->city;
            $contact->state    = $request->state;
            $contact->postal   = $request->postal;
            return redirect()->route('user-home')->with('success', 'Data has been updated.');
        }else {
            $contact = new contact();
            $contact->gmail    = $request->gmail;
            $contact->street   = $request->street;
            $contact->city     = $request->city;
            $contact->state    = $request->state;
            $contact->postal   = $request->postal;
            $contact->status   = 0;
            $contact->userId   = session('users')->id;
            $contact->save();
            return redirect()->route('user-home')->with('success', 'Data has been save.');
        }
        


    }


    public function addEducation(Request $request ) {
        
        $request->validate([
            "elem" => "required",
            "yearElem" => "required",
            "highSchool" => "required",
            "yearhighSchool" => "required",
            "senior" => "required",
            "YearSenior" => "required",
        ]);

        $education = education::where('userId', session('users')->id)->first();
        if($education !== null) {
            $education->elem             = $request->elem;
            $education->yearElem         = $request->yearElem;
            $education->highSchool       = $request->highSchool;
            $education->yearhighSchool   = $request->yearhighSchool;
            $education->senior           = $request->senior;
            $education->YearSenior       = $request->YearSenior;
            $education->save();
            return redirect()->route('user-home')->with('success', 'Data has been updated.');
        }else {
            $education = new education();
            $education->elem             = $request->elem;
            $education->yearElem         = $request->yearElem;
            $education->highSchool       = $request->highSchool;
            $education->yearhighSchool   = $request->yearhighSchool;
            $education->senior           = $request->senior;
            $education->YearSenior       = $request->YearSenior;
            $education->status           = 0;
            $education->userId           = session('users')->id;
            $education->save();
            return redirect()->route('user-home')->with('success', 'Data has been save.');
        }

    }


    public function addAsk(Request $request ) {
        $request->validate([
            "job" => "required",
            "related" => "required",
        ]);

        $ask = ask::where('userId', session('users')->id)->first();
        if($ask !== null) {
            $ask->job      = $request->job;
            $ask->related  = $request->related;
            $ask->save();
            return redirect()->route('user-home')->with('success', 'Data has been updated.');
        } else {
            $ask = new ask();
            $ask->job      = $request->job;
            $ask->related  = $request->related;
            $ask->status   = 0;
            $ask->userId    = session('users')->id;
            $ask->save();
            return redirect()->route('user-home')->with('success', 'Data has been save.');
        }
    }


    public function addemploy(Request $request ) {
        $request->validate([
            "company" => "required",
            "job" => "required",
            "position" => "required",
        ]);

        // $jobs = job::where('userId', session('users')->id)->first();
            $job = new job();
            $job->company   = $request->company;
            $job->title       = $request->job;
            $job->position  = $request->position;
            $job->status    = 0;
            $job->userId    = session('users')->id;
            $job->save();
            return redirect()->route('user-listemployment')->with('success', 'Data has been save.');
        

    }

        //updateemployment
    public function addUpdateemployment(Request $request) {

        $request->validate([
            "company" => "required",
            "title" => "required",
            "position" => "required",
        ]);

        $job = job::where('id', $request->id)->first();
        $job->company   = $request->company;
        $job->title       = $request->title;
        $job->position  = $request->position;
        $job->save();
        return redirect()->route('user-listemployment')->with('success', 'Data has been updated.');
   

    }

    public function deleteUpdateemployment($jobId) {

        $job = Job::find($jobId);

        if ($job) {
            $job->delete();
            return redirect()->route('user-listemployment')->with('success', 'Data has been deleted.');
        } else {
            return redirect()->route('user-listemployment')->with('error', 'Job not found.');
        }

    }

    public function uploadProfile(Request $request)
    {
        $request->validate([
            'photo' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);
    
        // Store the uploaded image in the 'public/photos' directory
        $imagePath = $request->file('photo')->store('public/photos');
    
        // Retrieve the user's profile based on the user's ID in the session
        $profile = Profile::where('userId', session('users')->id)->first();
    
        if ($profile !== null) {
            // Get the file name with extension from the full image path
            $imageNameWithExtension = pathinfo($imagePath, PATHINFO_BASENAME);
    
            // Update the 'photo' (or 'profile') field with the file name and extension
            $profile->profile = $imageNameWithExtension;
            $profile->save();
    
            // Optionally, you can delete the old profile photo if needed
            // Storage::delete('public/photos/' . $profile->profile);
    
            return redirect()->route('user-home')->with('success', 'Profile photo has been updated.');
        }

        
    }




    
    public function settingPost(Request $request ) { 
    
        $request->validate([
            'username' => 'required',
            'password' => 'required|min:6', 
            'repeatPassword' => 'required|same:password',
        ]);

        $users = users::where('id', session('users')->id)->first();
        $users->username = $request->username;
        $users->password = Hash::make($request->password);
        $users->save();
        return back()->with('success', 'Data has been saved.');


    }
    
    

    




}
